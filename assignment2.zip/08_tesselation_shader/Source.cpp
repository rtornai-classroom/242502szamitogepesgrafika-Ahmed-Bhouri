enum eVertexArrayObject {
	VAOCurveData,
	VAOCount
};
enum eVertexBufferObject {
	VBOHermiteData,
	VBOBezierData,
	BOCount
};
enum eProgram {
	CurveTesselationProgram,
	QuadScreenProgram,
	ProgramCount
};
enum eTexture {
	NoTexture,		// fixes 0 sized array problem
	TextureCount
};

#include "common.cpp"

#define	BEZIER_BERNSTEIN	3


GLchar	windowTitle[] = "Bezier Curves";
GLfloat				aspectRatio;

/* T�mb a g�rbe kontroll pontjainak t�rol�s�hoz. */
/* Array for storing the control points of a curve. */
static vector<vec3>	bezier_control_points = {
	vec3(-0.5f, -0.5f, 0.0f),
	vec3(-0.5f,  0.5f, 0.0f),
	vec3(0.5f, -0.5f, 0.0f),
	vec3(0.5f,  0.5f, 0.0f),
};


static array<vec3, 3> color[2] = {	// 2 sets, 3 colors, 3 components
	{ // R     G     B
	vec3(1.0f, 0.0f, 0.0f),			// red
	vec3(0.0f, 1.0f, 0.0f),			// green
	vec3(0.0f, 0.0f, 1.0f)			// blue
	} , {
	vec3(0.0f, 1.0f, 1.0f),			// cyan
	vec3(1.0f, 0.0f, 1.0f),			// magenta
	vec3(1.0f, 1.0f, 0.0f)			// yellow
	}
};

/** A shader v�ltoz�k location-jei �s a CPU oldali v�ltoz�ik. */
/** Shader variable locations and the corresponding CPU variables. */
GLuint			locationTessMatProjection, locationTessMatModelView, locationCurveType, locationControlPointsNumber;
GLuint			curveType = BEZIER_BERNSTEIN, controlPointsNumber = 4;

GLint				dragged = -1;

void initTesselationShader() {
	ShaderInfo shader_info[] = {
		{ GL_FRAGMENT_SHADER,			"./CurveFragShader.glsl" },
		{ GL_TESS_CONTROL_SHADER,		"./CurveTessContShader.glsl" },
		{ GL_TESS_EVALUATION_SHADER,	"./CurveTessEvalShader.glsl" },
		{ GL_VERTEX_SHADER,				"./CurveVertShader.glsl" },
		{ GL_NONE,						nullptr }
	};
	/** G�rberajzol� program elk�sz�t�se. */
	/** Creating the curve drawing program. */
	program[CurveTesselationProgram] = LoadShaders(shader_info);
	/** A g�rbe adatainak be�ll�t�sa. */
	/** Set the data for the curve. */
	/** Csatoljuk a vertex array objektumunkat a shader programhoz. */
	/** Attach the vertex array object to the shader program. */
	glBindVertexArray(VAO[VAOCurveData]);
	/** A GL_ARRAY_BUFFER neves�tett csatol�ponthoz kapcsoljuk a vertex buffert (ide ker�lnek a cs�cspont adatok). */
	/** We attach the vertex buffer to the GL_ARRAY_BUFFER node (vertices are stored here). */
	/** M�soljuk az adatokat a bufferbe! Megadjuk az aktu�lisan csatolt buffert, azt hogy h�ny byte adatot m�solunk,
		a m�soland� adatot, majd a feldolgoz�s m�dj�t is meghat�rozzuk: most az adat nem v�ltozik a felt�lt�s ut�n. */
	/** Same for Bezier. */
	glBindBuffer(GL_ARRAY_BUFFER, BO[VBOBezierData]);

	glBufferData(GL_ARRAY_BUFFER, bezier_control_points.size() * sizeof(vec3), bezier_control_points.data(), GL_STATIC_DRAW);
	/** Ezen adatok szolg�lj�k a location = 0 vertex attrib�tumot (itt: poz�ci�).
	    Els�k�nt megadjuk ezt az azonos�t�sz�mot (vertexShader.glsl).
	    Ut�na az attrib�tum m�ret�t (vec3, l�ttuk a shaderben).
	    Harmadik az adat t�pusa.
	    Negyedik az adat normaliz�l�sa, ez maradhat FALSE jelen p�ld�ban.
	    Az attrib�tum �rt�kek hogyan k�vetkeznek egym�s ut�n? Milyen l�p�sk�z ut�n tal�lom a k�vetkez� vertex adatait?
	    V�g�l megadom azt, hogy honnan kezd�dnek az �rt�kek a pufferben. Most r�gt�n, a legelej�t�l veszem �ket. */
	/** These values are for location = 0 vertex attribute (position).
		First is the location (vertexShader.glsl).
		Second is attribute size (vec3, as in the shader).
		Third is the data type.
		Fourth defines whether data shall be normalized or not, this is FALSE for the examples of the course.
		Fifth is the distance in bytes to the next vertex element of the array.
		Last is the offset of the first vertex data of the buffer. Now it is the start of the array. */
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	/** Enged�lyezz�k az im�nt defini�lt location = 0 attrib�tumot (HermiteCurveVertShader.glsl). */
	/** Enable the previously defined location = 0 attributum (HermiteCurveVertShader.glsl). */
	glEnableVertexAttribArray(0);
	/** A shader v�ltoz�k location-jeinek lek�rdez�se �s v�ltoz�k be�ll�t�sa. */
	/** Get shader variable locations and set the corresponding variables. */
	locationCurveType = glGetUniformLocation(program[CurveTesselationProgram], "curveType");
	locationControlPointsNumber = glGetUniformLocation(program[CurveTesselationProgram], "controlPointsNumber");
	locationTessMatProjection = glGetUniformLocation(program[CurveTesselationProgram], "matProjection");
	locationTessMatModelView = glGetUniformLocation(program[CurveTesselationProgram], "matModelView");
	glUseProgram(program[CurveTesselationProgram]);
	glUniform1i(locationCurveType, curveType);
	glUniform1i(locationControlPointsNumber, controlPointsNumber);
}


GLfloat distanceSquare(vec3 p1, vec3 p2) {
	vec2		delta = p1 - p2;	// delta.xy = p1.xy - p2.xy
	/** delta.x �s delta.y seg�ts�g�vel ki tudjuk sz�molni p1 �s p2 pontok t�vols�g�nak n�gyzet�t. */
	/** From delta.x and delta.y we can calculate the square of the distance of p1 and p2 points. */
	return dot(delta, delta);		// delta.x * delta.x + delta.y * delta.y
}
/** mousePos az eg�r poz�ci�ja, amit param�terk�nt kapunk. */
/** mousePos is the mouse position, arriving as vec2. */
GLint getActivePoint(vector<vec3> p, GLfloat sensitivity, vec2 mousePosition) {
	/** Ha az s a sensitivity n�gyzete, akkor a t�vols�g sz�m�t�sn�l �s hasonl�t�sn�l megtakar�thatunk egy n�gyzetgy�kvon�st. Ez jelent�s gyors�t�s. */
	/** If s is square of the sensitivity, then we can spare a square root computation at the distance calculations and comparisons. This is a significant speedup. */
	GLfloat		sensitivitySquare = sensitivity * sensitivity;
	/** Az egyes p pontok t�vols�g n�gyzet�nek vizsg�lata a mousePosition poz�ci�j�hoz. */
	/** Checking the square of the distanse of each p to mousePosition. */
	for (GLint i = 0; i < p.size(); i++)
		if (distanceSquare(p[i], vec3(mousePosition, 0.0f)) < sensitivitySquare)
			/** Ha p k�zelebb van a sensitivity-ben megadott �rt�kn�l, akkor visszat�r�nk vele, mint megragadott ponttal akkor is, ha van n�la k�zelebbi a vektorban h�tr�bb. */
			/** If p is closer than the sensitivity, then it is returned as a grabbed point even if there is closer later in the vector of points. */
			return i;
	/** Semmi sincs k�zel az eg�rhez, -1 jelent�se, hogy semmit nem fogtunk meg �s vonszolunk magunkkal. */
	/** Nothing is close to the mouse, -1 means that nothing is grabbed and dragged. */
	return -1;
}


void initShaderProgram() {
	ShaderInfo shader_info[] = {
		{ GL_FRAGMENT_SHADER,			"./QuadScreenFragShader.glsl" },
		{ GL_VERTEX_SHADER,				"./QuadScreenVertShader.glsl" },
		{ GL_NONE,						nullptr }
	};
	/** A vertex-fragment program elk�sz�t�se. */
	/** Creating the vertex-fragment program. */
	program[QuadScreenProgram] = LoadShaders(shader_info);
	locationMatProjection = glGetUniformLocation(program[QuadScreenProgram], "matProjection");
	locationMatModelView = glGetUniformLocation(program[QuadScreenProgram], "matModelView");
}

void display(GLFWwindow* window, double currentTime) {
	/** T�r�lj�k le a kiv�lasztott buffereket! Fontos lehet minden egyes alkalommal t�r�lni! */
	/** Let's clear the selected buffers! Usually importand to clear it each time! */
	glClear(GL_COLOR_BUFFER_BIT);
	/** Aktiv�ljuk a shader-program objektumunkat az alap�rtelmezett fix cs�vezet�k helyett. */
	/** Activate our shader-program object instead of the default fix pipeline. */
	glUseProgram(program[CurveTesselationProgram]);
	/** A megadott adatok seg�ts�g�vel megrajzoljuk a g�rb�t. */
	/** We draw a curve with the defined array. */

		glPatchParameteri(GL_PATCH_VERTICES, controlPointsNumber);
		glDrawArrays(GL_PATCHES, 0, controlPointsNumber);

	/** Aktiv�ljuk a shader-program objektumunkat az alap�rtelmezett fix cs�vezet�k helyett. */
	/** Activate our shader-program object instead of the default fix pipeline. */
	glUseProgram(program[QuadScreenProgram]);
	/** A megadott adatok seg�ts�g�vel megrajzoljuk a g�rb�t �s v�gpontjait. */
	/** We draw the curve and its end points. */
		glDrawArrays(GL_LINE_STRIP, 0, controlPointsNumber);

		glDrawArrays(GL_POINTS, 0, controlPointsNumber);

	
}

void framebufferSizeCallback(GLFWwindow* window, int width, int height) {
	/** A minimaliz�l�s nem fog fagyni a minimum 1 �rt�kkel. */
	/** Minimize will not freeze with minimum value 1. */
	windowWidth = glm::max(width, 1);
	windowHeight = glm::max(height, 1);

	aspectRatio = (float)windowWidth / (float)windowHeight;
	/** A kezelt k�perny� be�ll�t�sa a teljes (0, 0, width, height) ter�letre. */
	/** Set the viewport for the full (0, 0, width, height) area. */
	glViewport(0, 0, windowWidth, windowHeight);
	/** Orthographic projekci� be�ll�t�sa, worldSize lesz a sz�less�g �s magass�g k�z�l a kisebbik. */
	/** Set up orthographic projection, worldSize will equal the smaller value of width or height. */
	if (projectionType == Orthographic)
		if (windowWidth < windowHeight)
			matProjection = ortho(-worldSize, worldSize, -worldSize / aspectRatio, worldSize / aspectRatio, -100.0, 100.0);
		else
			matProjection = ortho(-worldSize * aspectRatio, worldSize * aspectRatio, -worldSize, worldSize, -100.0, 100.0);
	else
		matProjection = perspective(
			radians(45.0f),	// The vertical Field of View, in radians: the amount of "zoom". Think "camera lens". Usually between 90� (extra wide) and 30� (quite zoomed in)
			aspectRatio,	// Aspect Ratio. Depends on the size of your window. Notice that 4/3 == 800/600 == 1280/960, sounds familiar?
			0.1f,			// Near clipping plane. Keep as big as possible, or you'll get precision issues.
			100.0f			// Far clipping plane. Keep as little as possible.
		);
	matModel = mat4(1.0);
	matView = lookAt(
		vec3(0.0f, 0.0f, 9.0f),		// the position of your camera, in world space
		vec3(0.0f, 0.0f, 0.0f),		// where you want to look at, in world space
		vec3(0.0f, 1.0f, 0.0f));	// upVector, probably glm::vec3(0,1,0), but (0,-1,0) would make you looking upside-down, which can be great too
	matModelView = matView * matModel;
	/** Az aktu�lis p�ldaprogram bekapcsol�sa. */
	/** Switch on the current sample program. */
	glUseProgram(program[QuadScreenProgram]);
	/** Uniform v�ltoz�k be�ll�t�sa. */
	/** Setup uniform variables. */
	glUniformMatrix4fv(locationMatModelView, 1, GL_FALSE, glm::value_ptr(matModelView));
	glUniformMatrix4fv(locationMatProjection, 1, GL_FALSE, glm::value_ptr(matProjection));
	/** Az aktu�lis p�ldaprogram bekapcsol�sa. */
	/** Switch on the current sample program. */
	glUseProgram(program[CurveTesselationProgram]);
	/** Uniform v�ltoz�k be�ll�t�sa. */
	/** Setup uniform variables. */
	glUniformMatrix4fv(locationTessMatModelView, 1, GL_FALSE, glm::value_ptr(matModelView));
	glUniformMatrix4fv(locationTessMatProjection, 1, GL_FALSE, glm::value_ptr(matProjection));
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	glUseProgram(program[CurveTesselationProgram]);
	/** ESC billenty�re kil�p�s. */
	/** Exit on ESC key. */
	if ((action == GLFW_PRESS) && (key == GLFW_KEY_ESCAPE)) glfwSetWindowShouldClose(window, GLFW_TRUE);
	/** A billenty�k lenyom�s�nak �s felenged�s�nek regisztr�l�sa. Lehet�v� teszi gombkombin�ci�k haszn�lat�t. */
	/** Let's register press and release events for keys. Enables the usage of key combinations. */
	if (action == GLFW_PRESS)
		keyboard[key] = GL_TRUE;
	else if (action == GLFW_RELEASE)
		keyboard[key] = GL_FALSE;

	/** �j param�terek �tvitele a program[CurveTesselationProgram] shaderbe. */
	/** Passing new parameters to program[CurveTesselationProgram] shader. */
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glUniform1i(locationCurveType, curveType);
	glUniform1i(locationControlPointsNumber, controlPointsNumber);
}

void cursorPosCallback(GLFWwindow* window, double xPos, double yPos) {
	/** Az eg�r mutat� hely�t kezel� f�ggv�ny. */
	/** Callback function for mouse position change. */

	if (dragged >= 0) {
		dvec2	mousePosition;
		mousePosition.x = xPos * 2.0f / (GLdouble)windowWidth - 1.0f;
		mousePosition.y = ((GLdouble)windowHeight - yPos) * 2.0f / (GLdouble)windowHeight - 1.0f;
		if (windowWidth < windowHeight)
			mousePosition.y /= aspectRatio;
		else
			mousePosition.x *= aspectRatio;
		/** T�roljuk el a m�dos�tott �rt�keket. */
		/** Let's store the modified values. */
		glUseProgram(program[CurveTesselationProgram]);
		bezier_control_points[dragged] =vec3( mousePosition, 0.0f);
		/** Mozgassuk a m�dos�tott �rt�keket a GPU mem�ri�j�ba. */
		/** Let's transfer the modified values to the GPU. */
		glBindBuffer(GL_ARRAY_BUFFER, BO[VBOBezierData]);
		glBufferData(GL_ARRAY_BUFFER, bezier_control_points.size() * sizeof(vec3), bezier_control_points.data(), GL_STATIC_DRAW);

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
		glUniform1i(locationCurveType, curveType);
		glUniform1i(locationControlPointsNumber, controlPointsNumber);
	}
}

void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods) {
	/** Az eg�r gombjaihoz k�thet� esem�nyek kezel�se. */
	/** Callback function for mouse button events. */
	if (action == GLFW_PRESS && button == GLFW_MOUSE_BUTTON_LEFT) {
		
		dvec2	mousePosition;
		/** Kinyerj�k az eg�rkurzor pixelkoordin�t�it. */
		/** Obtain the pixel coordinates of the mouse. */
		glfwGetCursorPos(window, &mousePosition.x, &mousePosition.y);
		cout << "mouseButtonCallback glfwGetCursorPos\t" << mousePosition.x << "\t" << mousePosition.y << endl;
		/** A pixelkoordin�t�k [-1..+1] intervallumra transzform�lt �rt�kei. */
		/** The pixelcoordinates transformed to the [-1..+1] interval values. */
		mousePosition.x = mousePosition.x * 2.0f / (GLdouble)windowWidth - 1.0f;
		mousePosition.y = ((GLdouble)windowHeight - mousePosition.y) * 2.0f / (GLdouble)windowHeight - 1.0f;
		if (windowWidth < windowHeight)
			mousePosition.y /= aspectRatio;
		else
			mousePosition.x *= aspectRatio;
		cout << "mouseButtonCallback normalized coords\t" << mousePosition.x << "\t" << mousePosition.y << endl;

		dragged = getActivePoint(bezier_control_points, 0.1f, mousePosition);

		if (dragged == -1) {
			glUseProgram(program[CurveTesselationProgram]);
			bezier_control_points.push_back(vec3(float(mousePosition.x), float(mousePosition.y), 0.0f));

			controlPointsNumber++;
			glBindBuffer(GL_ARRAY_BUFFER, BO[VBOBezierData]);
			glBufferData(GL_ARRAY_BUFFER, bezier_control_points.size() * sizeof(vec3), bezier_control_points.data(), GL_STATIC_DRAW);

			glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
			glUniform1i(locationCurveType, curveType);
			glUniform1i(locationControlPointsNumber, controlPointsNumber);

		}

		

		cout << dragged;
	}

	if (action == GLFW_PRESS && button == GLFW_MOUSE_BUTTON_RIGHT) {

		dvec2	mousePosition;
		glfwGetCursorPos(window, &mousePosition.x, &mousePosition.y);
		mousePosition.x = mousePosition.x * 2.0f / (GLdouble)windowWidth - 1.0f;
		mousePosition.y = ((GLdouble)windowHeight - mousePosition.y) * 2.0f / (GLdouble)windowHeight - 1.0f;
		if (windowWidth < windowHeight)
			mousePosition.y /= aspectRatio;
		else
			mousePosition.x *= aspectRatio;

		int point = getActivePoint(bezier_control_points, 0.1f, mousePosition);

		cout << point;
		if (point >= 0) {
			glUseProgram(program[CurveTesselationProgram]);

			bezier_control_points.erase(bezier_control_points.begin() + point);

			controlPointsNumber--;

			glBindBuffer(GL_ARRAY_BUFFER, BO[VBOBezierData]);
			glBufferData(GL_ARRAY_BUFFER, bezier_control_points.size() * sizeof(vec3), bezier_control_points.data(), GL_STATIC_DRAW);

			glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
			glUniform1i(locationCurveType, curveType);
			glUniform1i(locationControlPointsNumber, controlPointsNumber);
		}
		


	}


	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE)
		dragged = -1;
}

int main(void) {
	/** Az alkalmaz�shoz kapcsol�d� el�k�sz�t� l�p�sek (param�terek: major, minor OpenGL verzi�k, OpenGL pofile). */
	/** The first initialization steps of the program (params: major, minor OpenGL versions, OpenGL pofile). */
	init(4, 0, GLFW_OPENGL_COMPAT_PROFILE); // Tesselation shader core since 4.0
	/** A rajzol�shoz haszn�lt shader programok bet�lt�se. */
	/** Loading the shader programs for rendering. */
	initTesselationShader();
	initShaderProgram();
	/** Karakterk�dol�s a sz�vegekhez. */
	/** Setting locale for characters of texts. */
	setlocale(LC_ALL, "");

	GLint	param;
	GLfloat	params[4];
	glGetIntegerv(GL_MAX_PATCH_VERTICES, &param);						// The maximum number of vertices in a patch primitive.
	cout << "GL_MAX_PATCH_VERTICES, at least 32:\t\t\t\t" << param << endl;
	glGetIntegerv(GL_MAX_TESS_CONTROL_INPUT_COMPONENTS, &param);		// The number of components for tessellation control shader per - vertex inputs.
	cout << "GL_MAX_TESS_CONTROL_INPUT_COMPONENTS, at least 128:\t\t" << param << endl;
	glGetIntegerv(GL_MAX_TESS_CONTROL_OUTPUT_COMPONENTS, &param);		// The number of components for tessellation control shader per - vertex outputs.
	cout << "GL_MAX_TESS_CONTROL_OUTPUT_COMPONENTS, at least 128:\t\t" << param << endl;
	glGetIntegerv(GL_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS, &param);	// The number of components for tessellation control shader per - patch outputs.
	cout << "GL_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS, at least 4096:\t" << param << endl;
	glGetIntegerv(GL_MAX_TESS_GEN_LEVEL, &param);						// The maximum level supported by the tessellation primitive generator.
	cout << "GL_MAX_TESS_GEN_LEVEL, at least 64:\t\t\t\t" << param << endl;
	glGetIntegerv(GL_MAX_TESS_PATCH_COMPONENTS, &param);				// The number of components for tessellation control shader per - patch outputs.
	cout << "GL_MAX_TESS_PATCH_COMPONENTS, at least 120:\t\t\t" << param << endl;
	glGetFloatv(GL_PATCH_DEFAULT_INNER_LEVEL, params);					// The default inner tessellation level without a control shader.
	cout << "GL_PATCH_DEFAULT_INNER_LEVEL initially(1.0, 1.0):\t\t" << params[0] << ", " << params[1] << endl;
	glGetFloatv(GL_PATCH_DEFAULT_OUTER_LEVEL, params);					// The default outer tessellation level without a control shader.
	cout << "GL_PATCH_DEFAULT_OUTER_LEVEL initially(1.0, 1.0, 1.0, 1.0):\t" << params[0] << ", " << params[1] << ", " << params[2] << ", " << params[3] << endl;
	glGetIntegerv(GL_PATCH_VERTICES, &param);							// The number of vertices in the input patch.
	cout << "GL_MAX_PATCH_VERTICES, initially 3:\t\t\t\t" << param << endl;
	glGetIntegerv(GL_MAX_TESS_EVALUATION_INPUT_COMPONENTS, &param);		// The number of components for tesselation evaluation shader per - vertex inputs.
	cout << "GL_MAX_TESS_EVALUATION_INPUT_COMPONENTS, at least 128:\t\t" << param << endl;
	glGetIntegerv(GL_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS, &param);	// The number of components for tesselation evaluation shader per - vertex outputs.
	cout << "GL_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS, at least 128:\t\t" << param << endl;
	/** A k�perny� �tm�retez�s kezel�se. */
	/** Callback function for window size change. */
	framebufferSizeCallback(window, windowWidth, windowHeight);
	/** A megadott window strukt�ra "close flag" vizsg�lata. */
	/** Checks the "close flag" of the specified window. */
	while (!glfwWindowShouldClose(window)) {
		/** A k�d, amellyel rajzolni tudunk a GLFWwindow objektumunkba. */
		/** Call display function which will draw into the GLFWwindow object. */
		display(window, glfwGetTime());
		/** Double buffered m�k�d�s. */
		/** Double buffered working = swap the front and back buffer here. */
		glfwSwapBuffers(window);
		/** Esem�nyek kezel�se az ablakunkkal kapcsolatban, pl. gombnyom�s. */
		/** Handle events related to our window, e.g.: pressing a key or moving the mouse. */
		glfwPollEvents();
	}
	/** Felesleges objektumok t�rl�se. */
	/** Clenup the unnecessary objects. */
	cleanUpScene(EXIT_SUCCESS);
	/** Kil�p�s EXIT_SUCCESS k�ddal. */
	/** Stop the software and exit with EXIT_SUCCESS code. */
	return EXIT_SUCCESS;
}