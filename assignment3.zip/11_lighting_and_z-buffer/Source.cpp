#include <array>
#include <fstream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_inverse.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <math.h>
#include <string>
#include <vector>
#include <cmath>
#include <glm/gtc/matrix_transform.hpp>

#define _USE_MATH_DEFINES
#include <math.h>

//Seifeldin Negm O8F119


using namespace std;

GLFWwindow* window;

// normal keys are fom [0..255], arrow and special keys are from [256..511]
GLboolean keyboard[512] = { GL_FALSE };

int window_width = 600;
int window_height = 600;
char window_title[] = "Lighting and Z buffer";

unsigned int modelLoc;
unsigned int viewLoc;
unsigned int projectionLoc;
GLuint invTMatrixLoc;
GLuint lightPosLoc;

double lastMouseX = 0.0;
double lastMouseY = 0.0;
float yaw = -90.0f; // Initial yaw angle pointing towards negative z-axis
float pitch = 0.0f; // Initial pitch angle
bool firstMouse = true; // Flag to handle the initial mouse position
// Define cameraFront as a global variable
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);

// Vertices for three cubes
float vertices[] = {
    // Front
    -0.25f, -0.25f, 0.25f,   0.0f, 0.0f,  0.5f,  // Bottom-left
    0.25f, -0.25f, 0.25f,    0.0f, 0.0f,  0.5f,  // Bottom-right
    0.25f, 0.25f, 0.25f,     0.0f, 0.0f,  0.5f,  // Top-right
    0.25f, 0.25f, 0.25f,     0.0f, 0.0f,  0.5f,  // Top-right
    -0.25f, 0.25f, 0.25f,    0.0f, 0.0f,  0.5f,  // Top-left
    -0.25f, -0.25f, 0.25f,   0.0f, 0.0f,  0.5f,  // Bottom-left
    // Back
    -0.25f, -0.25f, -0.25f,  0.0f, 0.0f, -0.5f, // Bottom-left
    -0.25f, 0.25f, -0.25f,   0.0f, 0.0f, -0.5f, // Top-left
    0.25f, 0.25f, -0.25f,    0.0f, 0.0f, -0.5f, // Top-right
    0.25f, 0.25f, -0.25f,    0.0f, 0.0f, -0.5f, // Top-right
    0.25f, -0.25f, -0.25f,   0.0f, 0.0f, -0.5f, // Bottom-right
    -0.25f, -0.25f, -0.25f,  0.0f, 0.0f, -0.5f, // Bottom-left
    // Left
    -0.25f, 0.25f, -0.25f,   -0.5f, 0.0f, 0.0f, // Top-right
    -0.25f, 0.25f, 0.25f,    -0.5f, 0.0f, 0.0f, // Top-left
    -0.25f, -0.25f, 0.25f,   -0.5f, 0.0f, 0.0f, // Bottom-left
    -0.25f, -0.25f, 0.25f,   -0.5f, 0.0f, 0.0f, // Bottom-left
    -0.25f, -0.25f, -0.25f,  -0.5f, 0.0f, 0.0f, // Bottom-right
    -0.25f, 0.25f, -0.25f,   -0.5f, 0.0f, 0.0f, // Top-right
    // Right
    0.25f, 0.25f, -0.25f,     0.5f, 0.0f, 0.0f, // Top-left
    0.25f, 0.25f, 0.25f,      0.5f, 0.0f, 0.0f, // Top-right
    0.25f, -0.25f, 0.25f,     0.5f, 0.0f, 0.0f, // Bottom-right
    0.25f, -0.25f, 0.25f,     0.5f, 0.0f, 0.0f, // Bottom-right
    0.25f, -0.25f, -0.25f,    0.5f, 0.0f, 0.0f, // Bottom-left
    0.25f, 0.25f, -0.25f,     0.5f, 0.0f, 0.0f, // Top-left
    // Top
    -0.25f, 0.25f, -0.25f,   0.0f,  0.5f, 0.0f, // Bottom-right
    -0.25f, 0.25f, 0.25f,    0.0f,  0.5f, 0.0f, // Top-right
    0.25f, 0.25f, 0.25f,     0.0f,  0.5f, 0.0f, // Top-left
    0.25f, 0.25f, 0.25f,     0.0f,  0.5f, 0.0f, // Top-left
    0.25f, 0.25f, -0.25f,    0.0f,  0.5f, 0.0f, // Bottom-left
    -0.25f, 0.25f, -0.25f,   0.0f,  0.5f, 0.0f, // Bottom-right
    // Bottom
    -0.25f, -0.25f, -0.25f,  0.0f, -0.5f, 0.0f, // Top-right
    -0.25f, -0.25f, 0.25f,   0.0f, -0.5f, 0.0f, // Top-left
    0.25f, -0.25f, 0.25f,    0.0f, -0.5f, 0.0f, // Bottom-left
    0.25f, -0.25f, 0.25f,    0.0f, -0.5f, 0.0f, // Bottom-left
    0.25f, -0.25f, -0.25f,   0.0f, -0.5f, 0.0f, // Bottom-right
    -0.25f, -0.25f, -0.25f,  0.0f, -0.5f, 0.0f  // Top-right
};
// Vertices for the second cube
// Vertices for the second cube (adjusted to match size of the first cube)
float vertices2[] = {
    // Front
    0.25f, -0.25f, 0.25f,    0.0f, 0.0f,  0.5f,  // Bottom-left
    -0.25f, -0.25f, 0.25f,   0.0f, 0.0f,  0.5f,  // Bottom-right
    -0.25f, 0.25f, 0.25f,    0.0f, 0.0f,  0.5f,  // Top-right
    -0.25f, 0.25f, 0.25f,    0.0f, 0.0f,  0.5f,  // Top-right
    0.25f, 0.25f, 0.25f,     0.0f, 0.0f,  0.5f,  // Top-left
    0.25f, -0.25f, 0.25f,    0.0f, 0.0f,  0.5f,  // Bottom-left
    // Back
    0.25f, -0.25f, -0.25f,   0.0f, 0.0f, -0.5f, // Bottom-left
    0.25f, 0.25f, -0.25f,    0.0f, 0.0f, -0.5f, // Top-left
    -0.25f, 0.25f, -0.25f,   0.0f, 0.0f, -0.5f, // Top-right
    -0.25f, 0.25f, -0.25f,   0.0f, 0.0f, -0.5f, // Top-right
    -0.25f, -0.25f, -0.25f,  0.0f, 0.0f, -0.5f, // Bottom-right
    0.25f, -0.25f, -0.25f,   0.0f, 0.0f, -0.5f, // Bottom-left
    // Left
    0.25f, 0.25f, -0.25f,    -0.5f, 0.0f, 0.0f, // Top-right
    0.25f, 0.25f, 0.25f,     -0.5f, 0.0f, 0.0f, // Top-left
    0.25f, -0.25f, 0.25f,    -0.5f, 0.0f, 0.0f, // Bottom-left
    0.25f, -0.25f, 0.25f,    -0.5f, 0.0f, 0.0f, // Bottom-left
    0.25f, -0.25f, -0.25f,   -0.5f, 0.0f, 0.0f, // Bottom-right
    0.25f, 0.25f, -0.25f,    -0.5f, 0.0f, 0.0f, // Top-right
    // Right
    -0.25f, 0.25f, -0.25f,     0.5f, 0.0f, 0.0f, // Top-left
    -0.25f, 0.25f, 0.25f,      0.5f, 0.0f, 0.0f, // Top-right
    -0.25f, -0.25f, 0.25f,     0.5f, 0.0f, 0.0f, // Bottom-right
    -0.25f, -0.25f, 0.25f,     0.5f, 0.0f, 0.0f, // Bottom-right
    -0.25f, -0.25f, -0.25f,    0.5f, 0.0f, 0.0f, // Bottom-left
    -0.25f, 0.25f, -0.25f,     0.5f, 0.0f, 0.0f, // Top-left
    // Top
    0.25f, 0.25f, -0.25f,    0.0f,  0.5f, 0.0f, // Bottom-right
    0.25f, 0.25f, 0.25f,     0.0f,  0.5f, 0.0f, // Top-right
    -0.25f, 0.25f, 0.25f,     0.0f,  0.5f, 0.0f, // Top-left
    -0.25f, 0.25f, 0.25f,     0.0f,  0.5f, 0.0f, // Top-left
    -0.25f, 0.25f, -0.25f,    0.0f,  0.5f, 0.0f, // Bottom-left
    0.25f, 0.25f, -0.25f,    0.0f,   0.5f, 0.0f, // Bottom-right
    // Bottom
    0.25f, -0.25f, -0.25f,   0.0f, -0.5f, 0.0f, // Top-right
    0.25f, -0.25f, 0.25f,    0.0f, -0.5f, 0.0f, // Bottom-right
    -0.25f, -0.25f, 0.25f,    0.0f, -0.5f, 0.0f, // Bottom-left
    -0.25f, -0.25f, 0.25f,    0.0f, -0.5f, 0.0f, // Bottom-left
    -0.25f, -0.25f, -0.25f,   0.0f, -0.5f, 0.0f, // Top-left
    0.25f, -0.25f, -0.25f,   0.0f, -0.5f, 0.0f, // Top-right
};
float vertices3[] = {
    // Front
    -0.25f, -0.25f, 0.25f,   0.0f, 0.0f,  0.5f,  // Bottom-left
    0.25f, -0.25f, 0.25f,    0.0f, 0.0f,  0.5f,  // Bottom-right
    0.25f, 0.25f, 0.25f,     0.0f, 0.0f,  0.5f,  // Top-right
    0.25f, 0.25f, 0.25f,     0.0f, 0.0f,  0.5f,  // Top-right
    -0.25f, 0.25f, 0.25f,    0.0f, 0.0f,  0.5f,  // Top-left
    -0.25f, -0.25f, 0.25f,   0.0f, 0.0f,  0.5f,  // Bottom-left
    // Back
    -0.25f, -0.25f, -0.25f,  0.0f, 0.0f, -0.5f, // Bottom-left
    -0.25f, 0.25f, -0.25f,   0.0f, 0.0f, -0.5f, // Top-left
    0.25f, 0.25f, -0.25f,    0.0f, 0.0f, -0.5f, // Top-right
    0.25f, 0.25f, -0.25f,    0.0f, 0.0f, -0.5f, // Top-right
    0.25f, -0.25f, -0.25f,   0.0f, 0.0f, -0.5f, // Bottom-right
    -0.25f, -0.25f, -0.25f,  0.0f, 0.0f, -0.5f, // Bottom-left
    // Left
    -0.25f, 0.25f, -0.25f,   -0.5f, 0.0f, 0.0f, // Top-right
    -0.25f, 0.25f, 0.25f,    -0.5f, 0.0f, 0.0f, // Top-left
    -0.25f, -0.25f, 0.25f,   -0.5f, 0.0f, 0.0f, // Bottom-left
    -0.25f, -0.25f, 0.25f,   -0.5f, 0.0f, 0.0f, // Bottom-left
    -0.25f, -0.25f, -0.25f,  -0.5f, 0.0f, 0.0f, // Bottom-right
    -0.25f, 0.25f, -0.25f,   -0.5f, 0.0f, 0.0f, // Top-right
    // Right
    0.25f, 0.25f, -0.25f,     0.5f, 0.0f, 0.0f, // Top-left
    0.25f, 0.25f, 0.25f,      0.5f, 0.0f, 0.0f, // Top-right
    0.25f, -0.25f, 0.25f,     0.5f, 0.0f, 0.0f, // Bottom-right
    0.25f, -0.25f, 0.25f,     0.5f, 0.0f, 0.0f, // Bottom-right
    0.25f, -0.25f, -0.25f,    0.5f, 0.0f, 0.0f, // Bottom-left
    0.25f, 0.25f, -0.25f,     0.5f, 0.0f, 0.0f, // Top-left
    // Top
    -0.25f, 0.25f, -0.25f,   0.0f,  0.5f, 0.0f, // Bottom-right
    -0.25f, 0.25f, 0.25f,    0.0f,  0.5f, 0.0f, // Top-right
    0.25f, 0.25f, 0.25f,     0.0f,  0.5f, 0.0f, // Top-left
    0.25f, 0.25f, 0.25f,     0.0f,  0.5f, 0.0f, // Top-left
    0.25f, 0.25f, -0.25f,    0.0f,  0.5f, 0.0f, // Bottom-left
    -0.25f, 0.25f, -0.25f,   0.0f,  0.5f, 0.0f, // Bottom-right
    // Bottom
    -0.25f, -0.25f, -0.25f,  0.0f, -0.5f, 0.0f, // Top-right
    -0.25f, -0.25f, 0.25f,   0.0f, -0.5f, 0.0f, // Top-left
    0.25f, -0.25f, 0.25f,    0.0f, -0.5f, 0.0f, // Bottom-left
    0.25f, -0.25f, 0.25f,    0.0f, -0.5f, 0.0f, // Bottom-left
    0.25f, -0.25f, -0.25f,   0.0f, -0.5f, 0.0f, // Bottom-right
    -0.25f, -0.25f, -0.25f,  0.0f, -0.5f, 0.0f  // Top-right
};

#define numVBOs 3
#define numVAOs 3
GLuint VBO[numVBOs];
GLuint VAO[numVAOs];
GLuint objectColorLoc, sphereColorLoc;

GLuint renderingProgram;




glm::mat4 model, view, projection = glm::perspective(glm::radians(45.0f), (float)window_width / (float)window_height, 0.1f, 100.0f);
glm::mat4 invTmatrix, rotateM, scaleM;

GLdouble currentTime, deltaTime, lastTime = 0.0f;
GLfloat cameraSpeed;
float cylinderRadius = 2.0f; // Radius of the cylinder
float cylinderHeight = 4.0f; // Height of the cylinder
float minHeight = -cylinderHeight; // Minimum height based on camera's current position
float maxHeight = cylinderHeight; // Maximum height is the height of the cylinder


// Camera position, target, and up vector
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 2.0f),
cameraTarget = glm::vec3(0.0f, 0.0f, 0.0f),
cameraUpVector = glm::vec3(0.0f, 1.0f, 0.0f),
cameraMovingX = glm::vec3(-1.0f, 0.0f, 0.0f),
cameraMovingY = glm::vec3(0.0f, 1.0f, 0.0f);

// Headlight position
glm::vec3 lightPos;

bool checkOpenGLError()
{
    bool foundError = false;
    int glErr = glGetError();
    while (glErr != GL_NO_ERROR)
    {
        cout << "glError: " << glErr << endl;
        foundError = true;
        glErr = glGetError();
    }
    return foundError;
}

void printShaderLog(GLuint shader)
{
    int len = 0;
    int chWrittn = 0;
    char* log;
    glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &len);
    if (len > 0)
    {
        log = (char*)malloc(len);
        glGetShaderInfoLog(shader, len, &chWrittn, log);
        cout << "Shader Info Log: " << log << endl;
        free(log);
    }
}

void printProgramLog(int prog)
{
    int len = 0;
    int chWrittn = 0;
    char* log;
    glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
    if (len > 0)
    {
        log = (char*)malloc(len);
        glGetProgramInfoLog(prog, len, &chWrittn, log);
        cout << "Program Info Log: " << log << endl;
        free(log);
    }
}

string readShaderSource(const char* filePath)
{
    string content;
    ifstream fileStream(filePath, ios::in);
    string line = "";

    while (!fileStream.eof())
    {
        getline(fileStream, line);
        content.append(line + "\n");
    }
    fileStream.close();
    return content;
}


GLuint createShaderProgram() {
    GLint linked;

    // Vertex and fragment shader source strings for cube
    string vertShaderStr = readShaderSource("vertexShader.glsl");
    string fragShaderStr = readShaderSource("fragmentShader.glsl");

    // Create and compile vertex shader for cube
    GLuint vShader = glCreateShader(GL_VERTEX_SHADER);
    const char* vertShaderSrc = vertShaderStr.c_str();
    glShaderSource(vShader, 1, &vertShaderSrc, NULL);
    glCompileShader(vShader);
    checkOpenGLError();
    // Check compilation status for cube vertex shader
    // (omitted for brevity)

    // Create and compile fragment shader for cube
    GLuint fShader = glCreateShader(GL_FRAGMENT_SHADER);
    const char* fragShaderSrc = fragShaderStr.c_str();
    glShaderSource(fShader, 1, &fragShaderSrc, NULL);
    glCompileShader(fShader);
    checkOpenGLError();
    // Check compilation status for cube fragment shader
    // (omitted for brevity)

    // Create shader program for cube
    GLuint vfProgram = glCreateProgram();

    // Attach shaders and link shader program for cube
    glAttachShader(vfProgram, vShader);
    glAttachShader(vfProgram, fShader);
    glLinkProgram(vfProgram);
    checkOpenGLError();
    // Check linking status for cube shader program
    // (omitted for brevity)

    // Delete shaders (no longer needed after linking)
    glDeleteShader(vShader);
    glDeleteShader(fShader);


    return vfProgram;
}


void computeModelMatrix()
{
    scaleM = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f)); // Scale cubes to half size

    model = scaleM;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
}

void computeCameraMatrix()
{
    view = glm::lookAt(cameraPos, cameraTarget, cameraUpVector);
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
}
GLuint sphereVBO, sphereVAO, sphereEBO;



#include <vector>
#include <cmath>
// Generate sphere vertices and indices
std::vector<float> sphereVertices;
std::vector<unsigned int> sphereIndices;
void generateSphereVerticesAndIndices(std::vector<float>& vertices, std::vector<unsigned int>& indices, float radius, int sectorCount, int stackCount) {
    float x, y, z, xy;                              // vertex position
    float nx, ny, nz, lengthInv = 1.0f / radius;    // normal
    float s, t;                                     // texCoord

    float sectorStep = 2 * M_PI / sectorCount;
    float stackStep = M_PI / stackCount;
    float sectorAngle, stackAngle;

    for (int i = 0; i <= stackCount; ++i) {
        stackAngle = M_PI / 2 - i * stackStep;      // starting from pi/2 to -pi/2
        xy = radius * cosf(stackAngle);             // r * cos(u)
        z = radius * sinf(stackAngle);              // r * sin(u)

        // add (sectorCount+1) vertices per stack
        // the first and last vertices have same position and normal, but different texCoords
        for (int j = 0; j <= sectorCount; ++j) {
            sectorAngle = j * sectorStep;           // starting from 0 to 2pi

            // vertex position (x, y, z)
            x = xy * cosf(sectorAngle);             // r * cos(u) * cos(v)
            y = xy * sinf(sectorAngle);             // r * cos(u) * sin(v)
            vertices.push_back(x);
            vertices.push_back(y);
            vertices.push_back(z);

            // normalized vertex normal (nx, ny, nz)
            nx = x * lengthInv;
            ny = y * lengthInv;
            nz = z * lengthInv;
            vertices.push_back(nx);
            vertices.push_back(ny);
            vertices.push_back(nz);

            // vertex tex coord (s, t) range between [0, 1]
            s = (float)j / sectorCount;
            t = (float)i / stackCount;
            vertices.push_back(s);
            vertices.push_back(t);
        }
    }

    // Generate sphere indices
    int k1, k2;
    for (int i = 0; i < stackCount; ++i) {
        k1 = i * (sectorCount + 1);     // beginning of current stack
        k2 = k1 + sectorCount + 1;      // beginning of next stack

        for (int j = 0; j < sectorCount; ++j, ++k1, ++k2) {
            // 2 triangles per sector excluding first and last stacks
            // k1 => k2 => k1+1
            if (i != 0) {
                indices.push_back(k1);
                indices.push_back(k2);
                indices.push_back(k1 + 1);
            }

            // k1+1 => k2 => k2+1
            if (i != (stackCount - 1)) {
                indices.push_back(k1 + 1);
                indices.push_back(k2);
                indices.push_back(k2 + 1);
            }
        }
    }
}
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    static bool firstMouse = true;
    static double lastMouseX = xpos;
    static double lastMouseY = ypos;

    if (firstMouse)
    {
        lastMouseX = xpos;
        lastMouseY = ypos;
        firstMouse = false;
    }

    // Calculate mouse movement
    float xOffset = xpos - lastMouseX;
    float yOffset = lastMouseY - ypos; // Reversed since y-coordinates range from bottom to top

    lastMouseX = xpos;
    lastMouseY = ypos;

    float sensitivity = 0.1f; // Adjust sensitivity as needed
    xOffset *= sensitivity;
    yOffset *= sensitivity;

    // Check if left mouse button is pressed
    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
    {
        // Update yaw and pitch
        yaw += xOffset;
        pitch += yOffset;

        // Constrain pitch to avoid flipping
        if (pitch > 89.0f)
            pitch = 89.0f;
        if (pitch < -89.0f)
            pitch = -89.0f;

        // Update camera front vector
        glm::vec3 front;
        front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
        front.y = sin(glm::radians(pitch));
        front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
        cameraFront = glm::normalize(front);

        // Update camera position based on camera front vector and target position
        cameraPos = cameraTarget - cameraFront * glm::distance(cameraPos, cameraTarget);
        cameraPos.y = glm::clamp(cameraPos.y, minHeight, maxHeight);
    }
}




void init(GLFWwindow* window)
{
    renderingProgram = createShaderProgram();

    glGenBuffers(numVBOs, VBO);
    glGenVertexArrays(numVAOs, VAO);


    generateSphereVerticesAndIndices(sphereVertices, sphereIndices, 0.2f, 10.0f, 10.0f);
    // Generate buffers and vertex arrays for the sphere
    glGenBuffers(1, &sphereVBO);
    glGenVertexArrays(1, &sphereVAO);

    // Bind buffer data and set up vertex attributes for the sphere
    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * sphereVertices.size(), sphereVertices.data(), GL_STATIC_DRAW);

    glBindVertexArray(sphereVAO);
    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Normal attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // Texture coordinates attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    // Bind and initialize VBO for the first cube
    glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Bind and initialize VAO for the first cube
    glBindVertexArray(VAO[0]);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // Unbind VAO and VBO
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    // Bind and initialize VBO for the second cube
    glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);

    // Bind and initialize VAO for the second cube
    glBindVertexArray(VAO[1]);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // Unbind VAO and VBO
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    // Bind and initialize VBO for the third cube
    glBindBuffer(GL_ARRAY_BUFFER, VBO[2]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices3), vertices3, GL_STATIC_DRAW);

    // Bind and initialize VAO for the third cube
    glBindVertexArray(VAO[2]);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // Unbind VAO and VBO
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    modelLoc = glGetUniformLocation(renderingProgram, "model");
    viewLoc = glGetUniformLocation(renderingProgram, "view");
    projectionLoc = glGetUniformLocation(renderingProgram, "projection");
    glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));
    invTMatrixLoc = glGetUniformLocation(renderingProgram, "invTMatrix");
    lightPosLoc = glGetUniformLocation(renderingProgram, "lightPos");

    glfwSetCursorPosCallback(window, mouse_callback);

    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);


    glEnable(GL_DEPTH_TEST);
}
void processInput(GLFWwindow* window)
{
    float cameraSpeed = 0.5f;
    // Ensure camera stays within cylinder's height
  
    glm::vec3 forward = glm::normalize(glm::vec3(cameraTarget.x - cameraPos.x, 0.0f, cameraTarget.z - cameraPos.z));
    glm::vec3 right = glm::normalize(glm::cross(forward, cameraUpVector));

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) {
        cameraPos.y += cameraSpeed;  // Move camera upward
        cameraPos.y = glm::clamp(cameraPos.y, minHeight, maxHeight);
    }

    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) {
        cameraPos.y -= cameraSpeed;  // Move camera downward
        cameraPos.y = glm::clamp(cameraPos.y, minHeight, maxHeight);
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        cameraPos -= cameraSpeed * right;  // Move camera left
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS || glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        cameraPos += cameraSpeed * right;  // Move camera right
    if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)

   
    cameraPos.y = glm::clamp(cameraPos.y, minHeight, maxHeight);

    // Calculate angle around the cylinder based on current position
    float angle = atan2(cameraPos.z, cameraPos.x);
    // Calculate the new position on the cylinder's surface
    float x = cylinderRadius * cos(angle);
    float z = cylinderRadius * sin(angle);
    // Update camera position to stay on the surface of the cylinder
    cameraPos.x = x;
    cameraPos.z = z;
}



void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    currentTime = glfwGetTime() * 0.5;
    deltaTime = currentTime - lastTime;
    lastTime = currentTime;

    cameraSpeed = 5.0f * (GLfloat)deltaTime;

    // Enclose input handling in curly braces
    {
        processInput(window);
    }

    // Update light position
    float radius = 2.0f;
    float angle = currentTime * 2 * glm::pi<float>();
    float lightX = cos(angle) * radius;
    float lightZ = sin(angle) * radius;
    lightPos = glm::vec3(lightX, 0.0f, lightZ);

    glm::vec3 lightDirection = glm::normalize(-lightPos);

    computeModelMatrix();
    computeCameraMatrix();

    invTmatrix = glm::inverseTranspose(view * model);
    glUniformMatrix4fv(invTMatrixLoc, 1, GL_FALSE, glm::value_ptr(invTmatrix));

    glUniform3fv(lightPosLoc, 1, glm::value_ptr(lightPos));
    glUniform1i(glGetUniformLocation(renderingProgram, "isSphere"), 0);

    // Draw the first cube
    model = glm::mat4(1.0f); // Reset model matrix
    glBindVertexArray(VAO[0]);
    glDrawArrays(GL_TRIANGLES, 0, sizeof(vertices) / (6 * 4));

    glUseProgram(renderingProgram);
    model = glm::translate(glm::mat4(1.0f), lightPos) * glm::scale(glm::mat4(1.0f), glm::vec3(0.1f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glBindVertexArray(VAO[1]);


    // Draw the second cube with the desired gap
    float distanceBetweenCubes = 0.5f; // Side length of cube
    model = glm::translate(glm::mat4(1.0f), glm::vec3(distanceBetweenCubes, 0.0f, 0.0f)) * glm::scale(glm::mat4(1.0f), glm::vec3(0.5f)); // Translate and scale the second cube
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Set the model matrix uniform
    glBindVertexArray(VAO[1]); // Bind the VAO for the second cube
    glDrawArrays(GL_TRIANGLES, 0, sizeof(vertices2) / (6 * 4)); // Draw the second cube

    // Draw the third cube to the left of the first cube
    model = glm::translate(glm::mat4(1.0f), glm::vec3(-distanceBetweenCubes, 0.0f, 0.0f)) * glm::scale(glm::mat4(1.0f), glm::vec3(0.5f)); // Translate and scale the third cube
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Set the model matrix uniform
    glBindVertexArray(VAO[2]); // Bind the VAO for the third cube
    glDrawArrays(GL_TRIANGLES, 0, sizeof(vertices3) / (6 * 4)); // Draw the third cube

    // Draw the light sphere
    glUniform1i(glGetUniformLocation(renderingProgram, "isSphere"), 1);

    glUniform3f(glGetUniformLocation(renderingProgram, "sphereColor"), 1.0f, 0.0f, 0.0f); // Set sphere color to red
    glUseProgram(renderingProgram);

    model = glm::translate(glm::mat4(1.0f), lightPos) * glm::scale(glm::mat4(1.0f), glm::vec3(0.5f)); // Adjust light radius as needed
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glBindVertexArray(sphereVAO);
    glDrawArrays(GL_TRIANGLES, 0, sphereVertices.size() / 3);

    // Swap buffers and poll events
    glfwSwapBuffers(window);
    glfwPollEvents();

    glBindVertexArray(0);
}


void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GLFW_TRUE);

    if (action == GLFW_PRESS)
        keyboard[key] = GL_TRUE;
    else if (action == GLFW_RELEASE)
        keyboard[key] = GL_FALSE;
}

void window_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
    window_width = width;
    window_height = height;
}

int main()
{
    if (!glfwInit())
    {
        exit(EXIT_FAILURE);
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

    window = glfwCreateWindow(window_width, window_height, window_title, NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwSetKeyCallback(window, key_callback);
    glfwSetWindowSizeCallback(window, window_size_callback);

    init(window);

    while (!glfwWindowShouldClose(window))
    {
        display();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
