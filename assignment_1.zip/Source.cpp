//First Assignment - Bhouri Ahmed
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#define _USE_MATH_DEFINES
#include <math.h>

#include <vector>


using namespace std;

const int NUM_SEGMENTS = 100;
const float RADIUS = 0.2f;
const float BORDER_RADIUS = 0.22f;

bool isMoving = false;

const GLuint WIDTH = 700, HEIGHT = 700;
const GLfloat circleRadius = 0.2f;
GLfloat circlePosX = 0.5f, circlePosY = 0.5f;
GLfloat circleVelocityX = 0.001f, circleVelocityY = 0.001f;

GLfloat linePosY = 0.0f;
const GLfloat lineWidth = 0.25f;
const GLuint animation_angle = 35;

vector<float> generateCircleVertices(float radius) {
    vector<float> vertices;
    vertices.push_back(0.0f); // Center of the circle
    vertices.push_back(0.0f);

    for (int i = 0; i <= NUM_SEGMENTS; i++) {
        float angle = 2.0f * M_PI * i / NUM_SEGMENTS;
        vertices.push_back(radius * cos(angle));
        vertices.push_back(radius * sin(angle));
    }
    return vertices;
}

vector<float> generateLineVertices() {
    // Line at the center of the screen, spanning the full width
    float halfWidth = 0.25f;  // 1/4 of the window width
    vector<float> vertices = {
        -halfWidth, 0.0f, // Start point of the line
        halfWidth, 0.0f   // End point of the line
    };
    return vertices;
}


void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mode)
{

    if (key == GLFW_KEY_S )
    {
        isMoving = true;
    }

    if (key == GLFW_KEY_UP && action == GLFW_PRESS)
    {
        linePosY = min(linePosY += 0.1f, 0.95f);
    }
    else if (key == GLFW_KEY_DOWN && action == GLFW_PRESS)
    {
        linePosY = max(linePosY -= 0.1f, -0.95f);;
    }

    if (key == GLFW_KEY_UP && action == GLFW_REPEAT)
    {
        linePosY = min(linePosY += 0.02f, 0.95f);
    }
    else if (key == GLFW_KEY_DOWN && action == GLFW_REPEAT)
    {
        linePosY = max(linePosY -= 0.02f, -0.95f);;
    }
}

void updateCirclePosition()
{
    circlePosX += circleVelocityX * cos(animation_angle * M_PI / 180);
    circlePosY += circleVelocityY * sin(animation_angle * M_PI / 180);


    if (circlePosX + circleRadius >= 1.0f || circlePosX - circleRadius <= -1.0f)
    {
        circleVelocityX = -circleVelocityX;
    }
    if (circlePosY + circleRadius >= 1.0f || circlePosY - circleRadius <= -1.0f)
    {
        circleVelocityY = -circleVelocityY;
    }
}

string readShaderFile(const string& filePath) {
    ifstream file(filePath);
    if (!file.is_open()) {
        cerr << "Failed to open shader file: " << filePath << endl;
        return "";
    }

    stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}


int main()
{

    if (!glfwInit())
    {
        cerr << "Failed to initialize GLFW" << endl;
        return -1;
    }

    GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, "Assignment I - Bouncing Circle - VZLH7Z", nullptr, nullptr);

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

    if (!window)
    {
        cerr << "Failed to create GLFW window" << endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    glfwSetKeyCallback(window, keyCallback);

    if (glewInit() != GLEW_OK)
    {
        cerr << "Failed to initialize GLEW" << endl;
        return -1;
    }

    glViewport(0, 0, WIDTH, HEIGHT);

    // Generate circle and border vertices
    vector<float> circleVertices = generateCircleVertices(RADIUS);
    vector<float> borderVertices = generateCircleVertices(BORDER_RADIUS);

    // Generate line vertices
    vector<float> lineVertices = generateLineVertices();

    // Set up VBO & VAO for the circle
    GLuint VBO1, VAO1;
    glGenVertexArrays(1, &VAO1);
    glGenBuffers(1, &VBO1);
    glBindVertexArray(VAO1);
    glBindBuffer(GL_ARRAY_BUFFER, VBO1);
    glBufferData(GL_ARRAY_BUFFER, circleVertices.size() * sizeof(float), circleVertices.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void *)0);
    glEnableVertexAttribArray(0);

    // Set up VBO & VAO for the border
    GLuint VBO2, VAO2;
    glGenVertexArrays(1, &VAO2);
    glGenBuffers(1, &VBO2);
    glBindVertexArray(VAO2);
    glBindBuffer(GL_ARRAY_BUFFER, VBO2);
    glBufferData(GL_ARRAY_BUFFER, borderVertices.size() * sizeof(float), borderVertices.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void *)0);
    glEnableVertexAttribArray(0);

    // Set up VBO & VAO for the line
    GLuint VBO3, VAO3;
    glGenVertexArrays(1, &VAO3);
    glGenBuffers(1, &VBO3);
    glBindVertexArray(VAO3);
    glBindBuffer(GL_ARRAY_BUFFER, VBO3);
    glBufferData(GL_ARRAY_BUFFER, lineVertices.size() * sizeof(float), lineVertices.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    string circleVertexShaderSource = readShaderFile("circleVertexShader1.glsl");
    string lineVertexShaderSource = readShaderFile("lineVertexShader1.glsl");
    string circleFragmentShaderSource = readShaderFile("circleFragmentShader1.glsl");
    string lineFragmentShaderSource = readShaderFile("lineFragmentShader1.glsl");

    const char* circleVertexShaderCode = circleVertexShaderSource.c_str();
    const char* lineVertexShaderCode = lineVertexShaderSource.c_str();
    const char* circleFragmentShaderCode = circleFragmentShaderSource.c_str();
    const char* lineFragmentShaderCode = lineFragmentShaderSource.c_str();


    GLuint vertexCircleShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexCircleShader, 1, &circleVertexShaderCode, nullptr);
    glCompileShader(vertexCircleShader);

    GLuint fragmentCircleShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentCircleShader, 1, &circleFragmentShaderCode, nullptr);
    glCompileShader(fragmentCircleShader);



    GLuint vertexLineShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexLineShader, 1, &lineVertexShaderCode, nullptr);
    glCompileShader(vertexLineShader);

    GLuint fragmentLineShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentLineShader, 1, &lineFragmentShaderCode, nullptr);
    glCompileShader(fragmentLineShader);





    GLuint circleShaderProgram = glCreateProgram();
    glAttachShader(circleShaderProgram, vertexCircleShader);
    glAttachShader(circleShaderProgram, fragmentCircleShader);
    glLinkProgram(circleShaderProgram);

    glDeleteShader(vertexCircleShader);
    glDeleteShader(fragmentCircleShader);



    GLuint lineShaderProgram = glCreateProgram();
    glAttachShader(lineShaderProgram, vertexLineShader);
    glAttachShader(lineShaderProgram, fragmentLineShader);
    glLinkProgram(lineShaderProgram);

    glDeleteShader(vertexLineShader);
    glDeleteShader(fragmentLineShader);


    GLint circleColorLocation = glGetUniformLocation(circleShaderProgram, "circleColor");
    GLint circlePositionLocation = glGetUniformLocation(circleShaderProgram, "circlePosition");

    GLint lineColorLocation = glGetUniformLocation(lineShaderProgram, "lineColor");



    while (!glfwWindowShouldClose(window))
    {
        if(isMoving)updateCirclePosition();

        glClear(GL_COLOR_BUFFER_BIT);
        glClearColor(1.0f, 1.0f, 0.0f, 1.0f);

        glUseProgram(circleShaderProgram);

        bool c = fabs(circlePosY - linePosY) <= circleRadius && fabs(circlePosX) <= lineWidth + circleRadius;
        if (c) glUniform3f(circleColorLocation, 1.0f, 0.0f, 0.0f);
        else glUniform3f(circleColorLocation, 0.0f, 1.0f, 0.0f);

        
        

        glBindVertexArray(VAO2);
        glDrawArrays(GL_TRIANGLE_FAN, 0, NUM_SEGMENTS + 2);

        glUniform2f(circlePositionLocation, circlePosX, circlePosY);

        if (c) glUniform3f(circleColorLocation, 0.0f, 1.0f, 0.0f);
        else glUniform3f(circleColorLocation, 1.0f, 0.0f, 0.0f);

        glBindVertexArray(VAO1);
        glDrawArrays(GL_TRIANGLE_FAN, 0, NUM_SEGMENTS + 2);


        glUseProgram(lineShaderProgram);

        glUniform2f(circlePositionLocation, 0,linePosY);


        // Draw the blue line (1/4 width of the window)
        glUniform3f(lineColorLocation, 0.0f, 0.0f, 1.0f); // Blue
        glBindVertexArray(VAO3);
        glDrawArrays(GL_LINES, 0, 2);

        glfwSwapBuffers(window);

        glfwPollEvents();
    }

    glDeleteShader(vertexCircleShader);
    glDeleteShader(fragmentCircleShader);
    glDeleteShader(vertexLineShader);
    glDeleteShader(fragmentLineShader);

    glfwTerminate();
    return 0;
}

